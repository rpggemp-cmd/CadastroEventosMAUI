namespace CadastroEventosMAUI;
public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new NavigationPage(new Views.CadastroPage())
        {
            BarBackgroundColor = Color.FromArgb("#173B70"),
            BarTextColor = Colors.White
        };
    }
}
