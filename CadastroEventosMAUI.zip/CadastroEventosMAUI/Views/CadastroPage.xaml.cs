using CadastroEventosMAUI.Models;
namespace CadastroEventosMAUI.Views;

public partial class CadastroPage : ContentPage
{
    private readonly Evento evento = new();
    public CadastroPage()
    {
        InitializeComponent();
        BindingContext = evento; // associa os campos da tela à model Evento
    }

    private async void OnConcluirClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(evento.Nome) || string.IsNullOrWhiteSpace(evento.Local))
        {
            await DisplayAlert("Dados obrigatórios", "Informe o nome e o local do evento.", "OK");
            return;
        }
        if (evento.DataTermino.Date < evento.DataInicio.Date)
        {
            await DisplayAlert("Datas inválidas", "A data de término não pode ser anterior à data de início.", "OK");
            return;
        }
        if (evento.NumeroParticipantes < 1 || evento.CustoPorParticipante < 0)
        {
            await DisplayAlert("Valores inválidos", "Informe ao menos 1 participante e um custo não negativo.", "OK");
            return;
        }
        await Navigation.PushAsync(new ResumoPage(evento));
    }
}
