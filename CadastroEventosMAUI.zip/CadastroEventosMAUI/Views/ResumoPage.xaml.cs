using CadastroEventosMAUI.Models;
namespace CadastroEventosMAUI.Views;

public partial class ResumoPage : ContentPage
{
    public ResumoPage(Evento evento)
    {
        InitializeComponent();
        BindingContext = evento; // reutiliza os dados cadastrados na página de resumo
    }
    private async void OnVoltarClicked(object sender, EventArgs e) =>
        await Navigation.PopAsync();
}
