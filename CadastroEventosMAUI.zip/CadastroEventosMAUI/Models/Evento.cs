using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CadastroEventosMAUI.Models;

public class Evento : INotifyPropertyChanged
{
    private string nome = string.Empty;
    private DateTime dataInicio = DateTime.Today;
    private DateTime dataTermino = DateTime.Today.AddDays(1);
    private int numeroParticipantes = 1;
    private string local = string.Empty;
    private decimal custoPorParticipante;

    public string Nome { get => nome; set => SetField(ref nome, value); }
    public DateTime DataInicio { get => dataInicio; set { if (SetField(ref dataInicio, value)) OnPropertyChanged(nameof(Duracao)); } }
    public DateTime DataTermino { get => dataTermino; set { if (SetField(ref dataTermino, value)) OnPropertyChanged(nameof(Duracao)); } }
    public int NumeroParticipantes { get => numeroParticipantes; set { if (SetField(ref numeroParticipantes, value)) OnPropertyChanged(nameof(CustoTotal)); } }
    public string Local { get => local; set => SetField(ref local, value); }
    public decimal CustoPorParticipante { get => custoPorParticipante; set { if (SetField(ref custoPorParticipante, value)) OnPropertyChanged(nameof(CustoTotal)); } }

    // TimeSpan representa a diferença entre as duas datas; a duração é exibida em dias.
    public TimeSpan Duracao => (DataTermino.Date - DataInicio.Date);
    public int DuracaoEmDias => Math.Max(0, Duracao.Days + 1); // conta os dias do evento incluindo início e término
    public decimal CustoTotal => NumeroParticipantes * CustoPorParticipante;

    public event PropertyChangedEventHandler? PropertyChanged;
    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
